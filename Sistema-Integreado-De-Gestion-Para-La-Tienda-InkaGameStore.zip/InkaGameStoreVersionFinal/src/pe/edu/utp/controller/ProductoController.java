package pe.edu.utp.controller;

import pe.edu.utp.vista.GestorProductos;
import pe.edu.utp.vista.MenuAdmin;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import pe.edu.utp.dao.ProductoDao;
import pe.edu.utp.dto.InicioSesionDTO;
import pe.edu.utp.dto.SesionUsuario;
import pe.edu.utp.entity.Productos;
import pe.edu.utp.service.ExcelProductos;

public class ProductoController implements Runnable {

    String hora, minuto, segundo;
    Thread hilo;
    private Productos modelo;
    private ProductoDao pdao;
    private GestorProductos vista;
    private DefaultTableModel dtmodel = new DefaultTableModel();
    private JTable tabla;

    public static String fecha() {
        Date fecha = new Date();
        SimpleDateFormat formatofecha = new SimpleDateFormat("YYYY-MM-dd");
        return formatofecha.format(fecha);

    }

    public void Hora() {
        Calendar calendario = new GregorianCalendar();
        Date horaactual = new Date();
        calendario.setTime(horaactual);
        hora = calendario.get(Calendar.HOUR_OF_DAY) > 9 ? "" + calendario.get(Calendar.HOUR_OF_DAY) : "0" + calendario.get(Calendar.HOUR_OF_DAY);
        minuto = calendario.get(Calendar.MINUTE) > 9 ? "" + calendario.get(Calendar.MINUTE) : "0" + calendario.get(Calendar.MINUTE);
        segundo = calendario.get(Calendar.SECOND) > 9 ? "" + calendario.get(Calendar.SECOND) : "0" + calendario.get(Calendar.SECOND);
    }

    @Override
    public void run() {
        Thread current = Thread.currentThread();
        while (current == hilo) {
            Hora();
            vista.lblHora.setText(hora + ":" + minuto + ":" + segundo);
        }
    }

    // Constructor del controlador
    public ProductoController(Productos modelo, ProductoDao pdao, GestorProductos vista) {
        this.modelo = modelo;
        this.pdao = pdao;
        this.vista = vista;
        initialize();  // Vincula los eventos a los botones
    }

    public void llenarComboBoxCategorias() {     //metodo para item
        List<String> categorias = pdao.getCategorias();

        if (categorias.isEmpty()) {
            System.out.println("No se encontraron categorías");
        } else {
            vista.cbxCategoria.removeAllItems();
            for (String categoria : categorias) {
                vista.cbxCategoria.addItem(categoria);
            }
        }
    }

    public void llenarComboBoxProveedores() {
        List<String> proveedores = pdao.getProveedores();

        if (proveedores.isEmpty()) {
            System.out.println("No se encontraron Proveedores");
        } else {
            vista.cbxProveedor.removeAllItems();
            for (String proveedor : proveedores) {
                vista.cbxProveedor.addItem(proveedor);
            }
        }
    }

    private boolean validarCamposVacios() {
        if (vista.txtNombre.getText().isEmpty() || vista.txtNombre.getText().equals("Ingrese el Nombre del Producto...")
                || vista.txtPrecio.getText().isEmpty() || vista.txtPrecio.getText().equals("Ingrese el Precio...")
                || vista.txtStock.getText().isEmpty() || vista.txtStock.getText().equals("Ingrese el Stock...")
                || vista.txtDescripcion.getText().isEmpty()
                || vista.txtImagenRuta.getText().isEmpty() || vista.txtImagenRuta.getText().equals("Ingrese la Ruta...")
                || vista.lblImagen.getIcon()== null) {
            JOptionPane.showMessageDialog(null, "Por favor, llene los campos para agregar.");
            return false;
        }
        return true;
    }

    private void guardarProducto() {
        
        if (!validarCamposVacios()) {
            return;
        }
        String codigoBuscar = vista.txtID.getText().trim();
        boolean encontrado = false;
        for (int i = 0; i < vista.tblProductos.getRowCount(); i++) {
            Object valorCelda = vista.tblProductos.getValueAt(i, 0);

            if (codigoBuscar.equals(valorCelda.toString())) {
                encontrado = true;
                modificarProducto();
                limpiar();
                break;
            }
        }
        if (!encontrado) {
            try {
                System.out.println("Guardando Producto...");
                String categoriaSeleccionadaNombre = (String) vista.cbxCategoria.getSelectedItem();
                if (categoriaSeleccionadaNombre != null) {
                    int categoriaId = pdao.ObtenerIDCategoria(categoriaSeleccionadaNombre);
                    if (categoriaId != -1) {
                        modelo.setCategoria(String.valueOf(categoriaId));
                    } else {
                        JOptionPane.showMessageDialog(null, "Categoría no encontrada.");
                        return;
                    }
                }
                String ProveedorSeleccionadoNombre = (String) vista.cbxProveedor.getSelectedItem();
                if (ProveedorSeleccionadoNombre != null) {
                    int proveedorId = pdao.ObtenerIDProveedor(ProveedorSeleccionadoNombre);
                    if (proveedorId != -1) {
                        modelo.setProveedor(String.valueOf(proveedorId));
                    } else {
                        JOptionPane.showMessageDialog(null, "Categoría no encontrada.");
                        return;
                    }
                }
                modelo.setNombreProducto(vista.txtNombre.getText());
                modelo.setPrecio(Integer.parseInt(vista.txtPrecio.getText()));
                modelo.setStock(Integer.parseInt(vista.txtStock.getText()));
                modelo.setDescripcion(vista.txtDescripcion.getText());
                modelo.setFechaHoraAgregada(String.valueOf(vista.lblFecha.getText() + " " + vista.lblHora.getText()));
                modelo.setImagenRuta(vista.txtImagenRuta.getText());
                if (pdao.createProducto(modelo)) {
                    JOptionPane.showMessageDialog(null, "Empleado Guardado");
                    limpiar();
                    limpiarTabla();
                    listar();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al Guardar");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error en la conversión de números: " + e.getMessage());
            }
        }
    }

    private void eliminarProducto() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Desea eliminar este Producto?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            System.out.println("Eliminando Producto...");  // Depuración
            int fila = vista.tblProductos.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar una fila");
            } else {
                int id = Integer.parseInt(vista.tblProductos.getValueAt(fila, 0).toString());
                if (pdao.deleteProducto(id)) {
                    JOptionPane.showMessageDialog(null, "Producto Eliminado");
                    limpiarTabla();
                    listar();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al Eliminar");
                }
            }
        }
    }

    private void seleccionarProducto() {
        int selectedRow = vista.tblProductos.getSelectedRow();
        if (selectedRow >= 0) {
            // Obtén el ID del producto seleccionado
            String nombre = vista.tblProductos.getValueAt(selectedRow, 2).toString();

            // Supongamos que pdao.readProductos(id) devuelve una lista de objetos Productos
            List<Productos> productosList = pdao.readProductos(nombre);

            // Verifica que la lista no esté vacía
            if (!productosList.isEmpty()) {
                Productos productoSeleccionado = productosList.get(0);

                // Actualiza los campos de texto y el JLabel con los valores del producto
                vista.txtID.setText(String.valueOf(productoSeleccionado.getProducto_ID()));
                vista.txtNombre.setText(productoSeleccionado.getNombreProducto());
                vista.cbxCategoria.setSelectedItem(productoSeleccionado.getCategoria());
                vista.cbxProveedor.setSelectedItem(productoSeleccionado.getProveedor());

                vista.txtPrecio.setText(String.valueOf(productoSeleccionado.getPrecio()));
                vista.txtStock.setText(String.valueOf(productoSeleccionado.getStock()));
                vista.txtDescripcion.setText(productoSeleccionado.getDescripcion());
                vista.txtImagenRuta.setText(productoSeleccionado.getImagenRuta());
                System.out.println(productoSeleccionado.getImagenRuta());

                // Carga y muestra la imagen
                try {
                    Image foto = Toolkit.getDefaultToolkit().getImage(productoSeleccionado.getImagenRuta());
                    foto = foto.getScaledInstance(230, 160, Image.SCALE_SMOOTH);
                    vista.lblImagen.setIcon(new ImageIcon(foto));
                } catch (Exception e) {
                    System.out.println("Error al cargar la imagen: " + e.getMessage());
                    vista.lblImagen.setIcon(null); // Limpia la imagen si hay un error
                }

                // Cambia el color del texto para que no parezca un placeholder
                vista.txtID.setForeground(Color.black);
                vista.txtNombre.setForeground(Color.black);
                vista.txtPrecio.setForeground(Color.black);
                vista.txtStock.setForeground(Color.black);
                vista.txtDescripcion.setForeground(Color.black);
                vista.txtImagenRuta.setForeground(Color.black);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún producto con el nombre: " + nombre);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para modificar");
        }
    }

    private void modificarProducto() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de guardar los cambios?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            System.out.println("Modificando Producto...");  // Depuración
            modelo.setProducto_ID(Integer.parseInt(vista.txtID.getText()));  // Se obtiene el ID del producto
            modelo.setNombreProducto(vista.txtNombre.getText());  // Se obtiene el nombre del producto
            String categoriaSeleccionadaNombre = (String) vista.cbxCategoria.getSelectedItem();
            if (categoriaSeleccionadaNombre != null) {
                int categoriaId = pdao.ObtenerIDCategoria(categoriaSeleccionadaNombre);
                if (categoriaId != -1) {
                    modelo.setCategoria(String.valueOf(categoriaId));
                } else {
                    JOptionPane.showMessageDialog(null, "Categoría no encontrada.");
                    return;
                }
            }
            String ProveedorSeleccionadoNombre = (String) vista.cbxProveedor.getSelectedItem();
            if (ProveedorSeleccionadoNombre != null) {
                int proveedorId = pdao.ObtenerIDProveedor(ProveedorSeleccionadoNombre);
                if (proveedorId != -1) {
                    modelo.setProveedor(String.valueOf(proveedorId));
                } else {
                    JOptionPane.showMessageDialog(null, "Categoría no encontrada.");
                    return;
                }
            }
            modelo.setPrecio(Double.parseDouble(vista.txtPrecio.getText()));
            modelo.setStock(Integer.parseInt(vista.txtStock.getText()));
            modelo.setDescripcion(vista.txtDescripcion.getText());
            modelo.setImagenRuta(vista.txtImagenRuta.getText());

            if (pdao.updateProducto(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto Modificado");
                limpiar();
                limpiarTabla();
                listar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Modificar el Producto");
            }
        }

    }

    private void inspeccionar() {
        // Creamos una instancia
        JFileChooser archivo = new JFileChooser();
        // Creamos un objeto File que representa el directorio predeterminado
        File ruta = new File("C:\\Users\\ASUS\\OneDrive\\Documentos\\ProyFinalIntegrador\\ProyFinal\\InkaGameImagenes\\InkaGame");
        // Establece el nuevo directorio 
        archivo.setCurrentDirectory(ruta);
        int ventana = archivo.showOpenDialog(null);
        if (ventana == JFileChooser.APPROVE_OPTION) {
            // Asignamos el archivo a la variable
            File file = archivo.getSelectedFile();
            // Establece la ruta del archivo seleccionado como cadena
            vista.txtImagenRuta.setText(String.valueOf(file));
            try {
                // Se carga la imagen desde la ruta
                Image foto = ImageIO.read(file);
                // Asignamos el tamaño con un suavizado para mejor calidad
                foto = foto.getScaledInstance(190, 130, Image.SCALE_SMOOTH);
                // Se crea un icono con la imagen redimensionada
                vista.lblImagen.setIcon(new ImageIcon(foto));
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cargar la imagen");
            }
        }
    }

    private void listar() {
        System.out.println("Listando Productos...");  // Depuración
        dtmodel = (DefaultTableModel) vista.tblProductos.getModel();
        dtmodel.setRowCount(0);
        List<Productos> lista = pdao.readAllProductos();
        for (Productos producto : lista) {
            Object[] objeto = new Object[10];
            objeto[0] = producto.getProducto_ID();
            objeto[1] = producto.getCategoria();
            objeto[2] = producto.getNombreProducto();
            objeto[3] = producto.getProveedor();
            objeto[4] = producto.getPrecio();
            objeto[5] = producto.getStock();
            objeto[6] = producto.getFechaHoraAgregada();
            objeto[7] = producto.getDescripcion();

            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);

            for (int i = 0; i < vista.tblProductos.getColumnCount(); i++) {
                vista.tblProductos.getColumnModel().getColumn(i).setHeaderRenderer(centerRenderer);
            }
            for (int i = 0; i < vista.tblProductos.getColumnCount(); i++) {
                vista.tblProductos.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
            dtmodel.addRow(objeto);
        }
        vista.tblProductos.setRowHeight(70);
        vista.tblProductos.setModel(dtmodel);
    }

    private void limpiarTabla() {
        System.out.println("Limpiando tabla de Empleado...");  // Depuración
        dtmodel.setRowCount(0);
    }

    private void regresar() {
        InicioSesionDTO usuarioLogeado = SesionUsuario.getUsuarioLogeado();
        MenuAdmin a = new MenuAdmin(usuarioLogeado);
        a.show();
        vista.dispose();
    }

    private void generarReporteExcel() {
        // Obtener lista de clientes
        List<Productos> listaProducto = pdao.readAllProductos();  // Obtiene todos los clientes desde ClientesDao
        if (!listaProducto.isEmpty()) {
            // Llamar al servicio para generar el reporte
            ExcelProductos.generarReporteProductos(listaProducto);
        } else {
            JOptionPane.showMessageDialog(null, "No hay clientes para generar el reporte.");
        }
    }

    private void limpiar() {
        System.out.println("Limpiando formulario...");  // Depuración
        vista.txtNombre.setText("Ingrese el Nombre del Producto...");
        vista.txtNombre.setForeground(new Color(153, 153, 153)); // Color del placeholder

        vista.txtPrecio.setText("Ingrese el Precio...");
        vista.txtPrecio.setForeground(new Color(153, 153, 153));

        vista.txtStock.setText("Ingrese el Stock...");
        vista.txtStock.setForeground(new Color(153, 153, 153));

        vista.txtImagenRuta.setText("Ingrese la Ruta...");
        vista.txtImagenRuta.setForeground(new Color(153, 153, 153));

        vista.lblImagen.setIcon(null);
        vista.txtDescripcion.setText("");

        vista.txtID.setText("AutoIncrementable**");
    }

    public void iniciar() {
        vista.setTitle("Gestor de Productos");
        vista.setLocationRelativeTo(null);
        vista.txtID.setEnabled(false);
        llenarComboBoxCategorias();
        llenarComboBoxProveedores();
        vista.lblFecha.setText(fecha());
        hilo = new Thread(this);
        hilo.start();
        listar();
    }

    private JTextField campoActual = null;

    private void txtMousePressed(JTextField textField, String placeholder) {
        // Si hay un campo actualmente seleccionado y no es el mismo, restablecer su placeholder
        if (campoActual != null && campoActual != textField) {
            if (campoActual.getText().isEmpty() || campoActual.getText().equals(getPlaceholderText(campoActual))) {
                resetPlaceholder(campoActual);
            }
        }
        campoActual = textField;
        if (textField.getText().equals(placeholder) && textField.getForeground().equals(new Color(153, 153, 153))) {
            textField.setText("");
            textField.setForeground(Color.black);
        }
    }

    private String getPlaceholderText(JTextField textField) {
        if (textField.equals(vista.txtID)) {
            return "AutoIncrementable**";
        } else if (textField.equals(vista.txtNombre)) {
            return "Ingrese el Nombre del Producto...";
        } else if (textField.equals(vista.txtPrecio)) {
            return "Ingrese el Precio...";
        } else if (textField.equals(vista.txtStock)) {
            return "Ingrese el Stock...";
        } else if (textField.equals(vista.txtImagenRuta)) {
            return "Ingrese la Ruta...";
        }
        return "";
    }

    private void resetPlaceholder(JTextField textField) {
        if (textField.equals(vista.txtID)) {
            textField.setText("AutoIncrementable**");
        } else if (textField.equals(vista.txtNombre)) {
            textField.setText("Ingrese el Nombre del Producto...");
        } else if (textField.equals(vista.txtPrecio)) {
            textField.setText("Ingrese el Precio...");
        } else if (textField.equals(vista.txtStock)) {
            textField.setText("Ingrese el Stock...");
        } else if (textField.equals(vista.txtImagenRuta)) {
            textField.setText("Ingrese la Ruta...");
        }
        textField.setForeground(new Color(153, 153, 153)); // Color del placeholder
    }

    private void initialize() {

        System.out.println("Inicializando botones y listeners...");  // Depuración
        this.vista.lblGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblInspeccionar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblExcel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        this.vista.lblGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblGuardar) {
                    System.out.println("label Guardar presionado");  // Depuración
                    guardarProducto();
                }
            }
        });
        this.vista.lblModificar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblModificar) {
                    System.out.println("label Modificar presionado");  // Depuración
                    seleccionarProducto();
                }
            }
        });
        this.vista.lblEliminar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblEliminar) {
                    System.out.println("label Eliminar presionado");  // Depuración
                    eliminarProducto();
                }
            }
        });
        this.vista.lblLimpiar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblLimpiar) {
                    System.out.println("label Limpiar presionado");  // Depuración
                    limpiar();
                }
            }
        });
        this.vista.lblRegresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblRegresar) {
                    System.out.println("label Regresar presionado");  // Depuración
                    regresar();
                }
            }
        });
        this.vista.lblInspeccionar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblInspeccionar) {
                    System.out.println("label Inspeccionar presionado");  // Depuración
                    inspeccionar();
                }
            }
        });

        // Agregar MouseListener a los campos de texto
        vista.txtNombre.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtNombre, "Ingrese el Nombre del Producto...");
            }
        });

        vista.txtPrecio.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtPrecio, "Ingrese el Precio...");
            }
        });

        vista.txtStock.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtStock, "Ingrese el Stock...");
            }
        });

        vista.txtImagenRuta.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtImagenRuta, "Ingrese la Ruta...");
            }
        });

        this.vista.lblExcel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblExcel) {
                    System.out.println("label Excel presionado");  // Depuración
                    generarReporteExcel();  // Llamada al método para generar el reporte
                }
            }
        });
        
        //ValidarCampos
        vista.txtNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (vista.txtNombre.getText().length() >= 190) {
                    e.consume();
                }
            }
        });
        vista.txtPrecio.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != '.') {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Solo se permiten números en el campo Precio.");
                }
            }
        });
        vista.txtStock.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Solo se permiten números en el campo Stock.");
                }
            }
        });

    }
}
