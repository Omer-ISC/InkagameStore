package pe.edu.utp.controller;

import pe.edu.utp.vista.GestorUsuarios;
import pe.edu.utp.vista.MenuAdmin;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import pe.edu.utp.entity.Usuario;
import pe.edu.utp.dao.UsuarioDao;
import pe.edu.utp.dto.InicioSesionDTO;
import pe.edu.utp.dto.SesionUsuario;
import pe.edu.utp.service.ExcelUsuarios;

/**
 *
 * @author javie
 */
public class UsuarioController {

    private Usuario modelo;
    private UsuarioDao pdao;
    private GestorUsuarios vista;
    private DefaultTableModel dtmodel = new DefaultTableModel();
    private JTable tabla;

    // Constructor del controlador
    public UsuarioController(Usuario modelo, UsuarioDao pdao, GestorUsuarios vista) {
        this.modelo = modelo;
        this.pdao = pdao;
        this.vista = vista;
        initialize();  // Vincula los eventos a los botones
    }

    private JTextField campoActual = null;

    private void RegresarMenu() {
        InicioSesionDTO usuarioLogeado = SesionUsuario.getUsuarioLogeado();
        MenuAdmin m = new MenuAdmin(usuarioLogeado);
        m.show();
    }

    // Método para iniciar la vista
    public void iniciar() {
        vista.setTitle("Gestor de Empleado");
        vista.setLocationRelativeTo(null);
        vista.txtID.setEnabled(false);
        listar();  // Lista los clientes al inicio
    }

    // Método para eliminar un empleado seleccionado de la tabla
    private void eliminarUsuario() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Desea eliminar este usuario?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            System.out.println("Eliminando Empleado...");  // Depuración
            int fila = vista.tblUsuario.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar una fila");
            } else {
                int id = Integer.parseInt(vista.tblUsuario.getValueAt(fila, 0).toString());
                if (pdao.deleteUsuario(id)) {
                    JOptionPane.showMessageDialog(null, "Empleado Eliminado");
                    limpiarTabla();
                    listar();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al Eliminar");
                }
            }
        }
    }

    private void seleccionarUsuario() {
        int selectedRow = vista.tblUsuario.getSelectedRow();
        if (selectedRow >= 0) {
            // Obtén el DNI del usuario seleccionado
            String dni = vista.tblUsuario.getValueAt(selectedRow, 2).toString();
            // Supongamos que udao.readUsuario(dni) devuelve una lista de objetos Usuario
            List<Usuario> usuariosList = pdao.readUsuario(dni);

            // Verifica que la lista no esté vacía
            if (!usuariosList.isEmpty()) {
                Usuario usuarioSeleccionado = usuariosList.get(0);

                // Actualiza los campos de texto y JComboBox con los valores del usuario
                vista.txtID.setText(String.valueOf(usuarioSeleccionado.getUsuario_ID()));
                vista.txtDNI.setText(usuarioSeleccionado.getDNI());
                vista.txtNombre.setText(usuarioSeleccionado.getNombreCompleto());
                vista.txtTelefono.setText(usuarioSeleccionado.getTelefono());
                vista.txtCorreo.setText(usuarioSeleccionado.getCorreo());
                vista.txtContraseña.setText(usuarioSeleccionado.getContraseña());
                vista.cbxRol.setSelectedItem(usuarioSeleccionado.getRol());
                vista.txtImagenRuta.setText(usuarioSeleccionado.getImagenRuta());

                // Carga y muestra la imagen
                try {
                    Image foto = Toolkit.getDefaultToolkit().getImage(usuarioSeleccionado.getImagenRuta());
                    foto = foto.getScaledInstance(140, 160, Image.SCALE_SMOOTH);
                    vista.lblPerfil.setIcon(new ImageIcon(foto));
                } catch (Exception e) {
                    System.out.println("Error al cargar la imagen: " + e.getMessage());
                    vista.lblPerfil.setIcon(null); // Limpia la imagen si hay un error
                }

                // Cambia el color del texto para que no parezca un placeholder
                vista.txtID.setForeground(Color.black);
                vista.txtDNI.setForeground(Color.black);
                vista.txtNombre.setForeground(Color.black);
                vista.txtTelefono.setForeground(Color.black);
                vista.txtCorreo.setForeground(Color.black);
                vista.txtContraseña.setForeground(Color.black);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún usuario con el DNI: " + dni);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para modificar");
        }
    }

    // Método para modificar un cliente existente
    private void modificarUsuario() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de guardar los cambios?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            System.out.println("Modificando Empleado...");  // Depuración
            modelo.setUsuario_ID(Integer.parseInt(vista.txtID.getText()));
            String rolSeleccionado = (String) vista.cbxRol.getSelectedItem();
            int rolID = rolSeleccionado.equals("Empleado") ? 1 : 2;
            modelo.setRol(String.valueOf(rolID));
            modelo.setDNI(vista.txtDNI.getText());
            modelo.setNombreCompleto(vista.txtNombre.getText());
            modelo.setTelefono(vista.txtTelefono.getText());
            modelo.setCorreo(vista.txtCorreo.getText());
            modelo.setContraseña(String.valueOf(vista.txtContraseña.getPassword()));
            modelo.setImagenRuta(vista.txtImagenRuta.getText());

            if (pdao.updateUsuario(modelo)) {
                JOptionPane.showMessageDialog(null, "Empleado Modificado");
                limpiar(); // Limpia el formulario después de modificar
                limpiarTabla();
                listar(); // Actualiza la tabla para mostrar los cambios
            } else {
                JOptionPane.showMessageDialog(null, "Error al Modificar");
            }
        }
    }

    private void generarReporteExcel() {
        // Obtener lista de clientes
        List<Usuario> listaUsuarios = pdao.readAllUsuario();  // Obtiene todos los clientes desde ClientesDao
        if (!listaUsuarios.isEmpty()) {
            // Llamar al servicio para generar el reporte
            ExcelUsuarios.generarReporteUsuarios(listaUsuarios);
        } else {
            JOptionPane.showMessageDialog(null, "No hay clientes para generar el reporte.");
        }
    }

    // Método para limpiar los campos del formulario
    private void limpiar() {
        System.out.println("Limpiando formulario...");  // Depuración
        vista.txtDNI.setText("Ingrese su DNI...");
        vista.txtDNI.setForeground(new Color(153, 153, 153)); // Color del placeholder

        vista.txtNombre.setText("Ingrese sus Nombres y Apellidos...");
        vista.txtNombre.setForeground(new Color(153, 153, 153));

        vista.txtTelefono.setText("Ingrese su Telefono...");
        vista.txtTelefono.setForeground(new Color(153, 153, 153));

        vista.txtCorreo.setText("Ingrese su Correo...");
        vista.txtCorreo.setForeground(new Color(153, 153, 153));

        vista.txtContraseña.setText("************");
        vista.txtContraseña.setForeground(new Color(153, 153, 153));

        vista.txtID.setText("AutoIncrementable");

        vista.lblPerfil.setIcon(null);
        vista.txtImagenRuta.setText("");
    }

    // Método para limpiar la tabla de Proveedores
    private void limpiarTabla() {
        System.out.println("Limpiando tabla de Empleado...");  // Depuración
        dtmodel.setRowCount(0);
    }

    private void listar() {
        System.out.println("Listando Usuarios...");  // Depuración
        dtmodel = (DefaultTableModel) vista.tblUsuario.getModel();
        vista.tblUsuario.setModel(dtmodel);
        List<Usuario> lista = pdao.readAllUsuario();
        Object[] objeto = new Object[7];  // Ajusta según los atributos de tu entidad Clientes
        for (int i = 0; i < lista.size(); i++) {
            objeto[0] = lista.get(i).getUsuario_ID();
            objeto[1] = lista.get(i).getRol();
            objeto[2] = lista.get(i).getDNI();
            objeto[3] = lista.get(i).getNombreCompleto();
            objeto[4] = lista.get(i).getTelefono();
            objeto[5] = lista.get(i).getCorreo();
            objeto[6] = lista.get(i).getContraseñaOculta();
            dtmodel.addRow(objeto);
        }
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < vista.tblUsuario.getColumnCount(); i++) {
            vista.tblUsuario.getColumnModel().getColumn(i).setHeaderRenderer(centerRenderer);
        }
        for (int i = 0; i < vista.tblUsuario.getColumnCount(); i++) {
            vista.tblUsuario.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        vista.tblUsuario.setModel(dtmodel);
    }

    private boolean validarCamposVacios() {
        if (vista.txtNombre.getText().isEmpty() || vista.txtNombre.getText().equals("Ingrese sus Nombres y Apellidos...")
                || vista.txtDNI.getText().isEmpty() || vista.txtDNI.getText().equals("Ingrese su DNI...")
                || vista.txtTelefono.getText().isEmpty() || vista.txtTelefono.getText().equals("Ingrese su Telefono...")
                || vista.txtCorreo.getText().isEmpty() || vista.txtCorreo.getText().equals("Ingrese su Correo...")
                || vista.txtContraseña.getPassword().length == 0
                || Arrays.equals(vista.txtContraseña.getPassword(), "************".toCharArray())
                || vista.txtImagenRuta.getText().isEmpty() || vista.lblPerfil.getIcon() == null) {
            JOptionPane.showMessageDialog(null, "Por favor, llene los campos para agregar.");
            return false;
        }
        return true;
    }
    
    public boolean validarCorreo() {
        String correo = vista.txtCorreo.getText();
        if (!correo.contains("@")) {
            JOptionPane.showMessageDialog(null, "El correo debe contener el símbolo '@'.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(!validarContraseña()){
            return false;
        }
        return true;
    }

    private boolean validarContraseña() {
        char[] password = vista.txtContraseña.getPassword();
        if (password.length < 8) {
            JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 8 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
            vista.txtContraseña.requestFocus();
            return false;
        }
        return true;
    }
    // Método para guardar
    private void guardarUsuario() {
        if (!validarCamposVacios()) {
            return;
        }else if (!validarCorreo()) {
            return;
        }
        String codigoBuscar = vista.txtID.getText().trim();
        boolean encontrado = false;

        for (int i = 0; i < vista.tblUsuario.getRowCount(); i++) {
            Object valorCelda = vista.tblUsuario.getValueAt(i, 0);
            if (codigoBuscar.equals(valorCelda.toString())) {
                encontrado = true;
                modificarUsuario();
                limpiar();
                break;
            }
        }

        if (!encontrado) {
            try {
                System.out.println("Guardando Empleado...");
                String rolSeleccionado = (String) vista.cbxRol.getSelectedItem();
                int rolID = rolSeleccionado.equals("Empleado") ? 1 : 2; // Establece el rol

                modelo.setRol(String.valueOf(rolID));
                modelo.setDNI(vista.txtDNI.getText());
                modelo.setNombreCompleto(vista.txtNombre.getText());
                modelo.setTelefono(vista.txtTelefono.getText());
                modelo.setCorreo(vista.txtCorreo.getText());
                modelo.setContraseña(String.valueOf(vista.txtContraseña.getPassword()));
                modelo.setImagenRuta(vista.txtImagenRuta.getText());

                if (pdao.createUsuario(modelo)) {
                    JOptionPane.showMessageDialog(null, "Empleado Guardado");
                    limpiar();
                    limpiarTabla();
                    listar();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al Guardar");
                }

            } catch (NumberFormatException e) {
                System.out.println("Error en la conversión de números: " + e.getMessage());
            }
        }
    }

    private void inspeccionar() {
        // Creamos una instancia
        JFileChooser archivo = new JFileChooser();
        // Creamos un objeto File que representa el directorio predeterminado
        File ruta = new File("C:\\Users\\ASUS\\OneDrive\\Documentos\\ProyFinalIntegrador\\ProyFinal\\InkaGameImagenes\\InkaGame");
        // Establece el nuevo directorio 
        archivo.setCurrentDirectory(ruta);
        int ventana = archivo.showOpenDialog(null);
        if (ventana == JFileChooser.APPROVE_OPTION) {
            // Asignamos el archivo a la variable
            File file = archivo.getSelectedFile();
            // Establece la ruta del archivo seleccionado como cadena
            vista.txtImagenRuta.setText(String.valueOf(file));
            try {
                // Se carga la imagen desde la ruta
                Image foto = ImageIO.read(file);
                // Asignamos el tamaño con un suavizado para mejor calidad
                foto = foto.getScaledInstance(140, 160, Image.SCALE_SMOOTH);
                // Se crea un icono con la imagen redimensionada
                vista.lblPerfil.setIcon(new ImageIcon(foto));
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cargar la imagen");
            }
        }
    }

    private void txtMousePressed(JTextField textField, String placeholder) {
        // Si hay un campo actualmente seleccionado y no es el mismo, restablecer su placeholder
        if (campoActual != null && campoActual != textField) {
            if (campoActual.getText().isEmpty() || campoActual.getText().equals(getPlaceholderText(campoActual))) {
                resetPlaceholder(campoActual);
            }
        }
        campoActual = textField;
        if (textField.getText().equals(placeholder) && textField.getForeground().equals(new Color(153, 153, 153))) {
            textField.setText("");
            textField.setForeground(Color.black);
        }
    }

    private String getPlaceholderText(JTextField textField) {
        if (textField.equals(vista.txtDNI)) {
            return "Ingrese su DNI...";
        } else if (textField.equals(vista.txtNombre)) {
            return "Ingrese sus Nombres y Apellidos...";
        } else if (textField.equals(vista.txtTelefono)) {
            return "Ingrese su Telefono...";
        } else if (textField.equals(vista.txtCorreo)) {
            return "Ingrese su Correo...";
        } else if (textField.equals(vista.txtContraseña)) {
            return "************";
        }
        return "";
    }

    private void resetPlaceholder(JTextField textField) {
        if (textField.equals(vista.txtDNI)) {
            textField.setText("Ingrese su DNI...");
        } else if (textField.equals(vista.txtNombre)) {
            textField.setText("Ingrese sus Nombres y Apellidos...");
        } else if (textField.equals(vista.txtTelefono)) {
            textField.setText("Ingrese su Telefono...");
        } else if (textField.equals(vista.txtCorreo)) {
            textField.setText("Ingrese su Correo...");
        } else if (textField.equals(vista.txtContraseña)) {
            textField.setText("************");
        }
        textField.setForeground(new Color(153, 153, 153)); // Color del placeholder
    }

    private void initialize() {

        System.out.println("Inicializando botones y listeners...");  // Depuración
        this.vista.lblGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblExcel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        this.vista.lblGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblGuardar) {
                    System.out.println("label Guardar presionado");  // Depuración
                    guardarUsuario();
                }
            }
        });
        this.vista.lblModificar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblModificar) {
                    System.out.println("label Modificar presionado");  // Depuración
                    seleccionarUsuario();
                }
            }
        });
        this.vista.lblEliminar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblEliminar) {
                    System.out.println("label Eliminar presionado");  // Depuración
                    eliminarUsuario();
                }
            }
        });
        this.vista.lblLimpiar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblLimpiar) {
                    System.out.println("label Limpiar presionado");  // Depuración
                    limpiar();
                }
            }
        });
        this.vista.lblRegresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblRegresar) {
                    System.out.println("label Regresar presionado");  // Depuración
                    RegresarMenu();
                    vista.dispose();
                }
            }
        });

        // Agregar MouseListener a los campos de texto
        vista.txtDNI.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtDNI, "Ingrese su DNI...");
            }
        });

        vista.txtNombre.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtNombre, "Ingrese sus Nombres y Apellidos...");
            }
        });

        vista.txtTelefono.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtTelefono, "Ingrese su Telefono...");
            }
        });

        vista.txtCorreo.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtCorreo, "Ingrese su Correo...");
            }
        });

        vista.txtContraseña.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtContraseña, "************");
            }
        });

        this.vista.lblExcel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblExcel) {
                    System.out.println("label Excel presionado");  // Depuración
                    generarReporteExcel();  // Llamada al método para generar el reporte
                }
            }
        });
        // Agregar MouseListener para detectar doble clic
        vista.lblPerfil.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {  // Detectar doble clic
                    inspeccionar();
                }
            }
        });
        //ValidarCampos
        vista.txtDNI.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Solo se permiten números en el campo DNI.");
                }
                if (vista.txtDNI.getText().length() >= 8) {
                    e.consume();
                }
            }
        });
        vista.txtNombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' ') {
                    e.consume();
                }
                if (vista.txtNombre.getText().length() >= 190) {
                    e.consume();
                }
            }
        });

        vista.txtTelefono.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Solo se permiten números en el campo Teléfono.");
                }
                if (vista.txtTelefono.getText().length() >= 9) {
                    e.consume();
                }
            }
        });

        vista.txtCorreo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (vista.txtCorreo.getText().length() >= 190) {
                    e.consume();
                }
            }
        });

        vista.txtContraseña.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (vista.txtContraseña.getText().length() >= 50) {
                    e.consume();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyChar() == KeyEvent.VK_ENTER) {
                    if (vista.txtContraseña.getPassword().length < 8) {
                        JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 8 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
                        vista.txtContraseña.requestFocus();
                    }
                }
            }
        });
    }

}
