package pe.edu.utp.controller;

import pe.edu.utp.vista.Login;
import pe.edu.utp.vista.MenuAdmin;
import pe.edu.utp.vista.MenuEmpleado;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import pe.edu.utp.dao.UsuarioDao;
import pe.edu.utp.dto.InicioSesionDTO;
import pe.edu.utp.dto.SesionUsuario;
import pe.edu.utp.entity.Usuario;

public class LoginController {

    private UsuarioDao pdao;
    private Login vista;

    // Constructor del controlador
    public LoginController(UsuarioDao pdao, Login vista) {
        this.pdao = pdao;
        this.vista = vista;
        initialize();  // Vincula los eventos a los botones
    }

    // Método para iniciar la vista
    public void iniciar() {
        vista.setTitle("Login");
        vista.setLocationRelativeTo(null);
    }
    public static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    private boolean validarCamposVacios() {
        if (vista.txtCorreo.getText().isEmpty() || vista.txtCorreo.getText().equals("Ingrese su Correo Electrónico...")
                || vista.txtContraseñaa.getPassword().length == 0
                || Arrays.equals(vista.txtContraseñaa.getPassword(), "************".toCharArray())) {
            JOptionPane.showMessageDialog(null, "Por favor, llene los campos para ingresar.");
            return false;
        }
        return true;
    }

    private void VerificarCredenciales() {
        List<Usuario> lista = pdao.readAllUsuario();
        String correo = vista.txtCorreo.getText();
        String contraseña = new String(vista.txtContraseñaa.getPassword());
        String hashedContraseña = md5(contraseña);
        if (!validarCamposVacios()) {
            return;
        }

        boolean usuarioEncontrado = false;

        for (Usuario usuario : lista) {
            if (usuario.getCorreo().equals(correo) && usuario.getContraseña().equals(hashedContraseña)) {
                usuarioEncontrado = true;

                InicioSesionDTO usuarioDTO = new InicioSesionDTO(usuario.getUsuario_ID(), usuario.getNombreCompleto(), usuario.getRol());
                SesionUsuario.iniciarSesion(usuarioDTO);

                if (usuario.getRol().equals("Empleado")) {
                    System.out.println("Coincidencia encontrada: Empleado");
                    InicioSesionDTO usuarioLogeado = SesionUsuario.getUsuarioLogeado();
                    MenuEmpleado m = new MenuEmpleado(usuarioLogeado);

                    m.setVisible(true);
                    vista.dispose();
                } else if (usuario.getRol().equals("Administrador")) {
                    System.out.println("Coincidencia encontrada: Administrador");
                    // Abrir la vista del menú de administrador
                    InicioSesionDTO usuarioLogeado = SesionUsuario.getUsuarioLogeado();
                    MenuAdmin a = new MenuAdmin(usuarioLogeado);
                    a.setVisible(true);
                    vista.dispose();
                }
                break;
            }
        }
        if (!usuarioEncontrado) {
            JOptionPane.showMessageDialog(null, "Credenciales inválidas, verifique su correo y contraseña.");
        }
    }

    private boolean mostrarContraseña = false;
    private JTextField campoActual = null;

    private void txtMousePressed(JTextField textField, String placeholder) {
        // Si hay un campo actualmente seleccionado y no es el mismo, restablecer su placeholder
        if (campoActual != null && campoActual != textField) {
            if (campoActual.getText().isEmpty() || campoActual.getText().equals(getPlaceholderText(campoActual))) {
                resetPlaceholder(campoActual);
            }
        }
        campoActual = textField;
        if (textField.getText().equals(placeholder) && textField.getForeground().equals(new Color(153, 153, 153))) {
            textField.setText("");
            textField.setForeground(Color.black);
        }
    }

    private String getPlaceholderText(JTextField textField) {
        if (textField.equals(vista.txtCorreo)) {
            return "Ingrese su DNI...";
        } else if (textField.equals(vista.txtContraseñaa)) {
            return "************";
        }
        return "";
    }

    private void resetPlaceholder(JTextField textField) {
        if (textField.equals(vista.txtCorreo)) {
            textField.setText("Ingrese su Correo Electrónico...");
        } else if (textField.equals(vista.txtContraseñaa)) {
            textField.setText("************");
        }
        textField.setForeground(new Color(153, 153, 153)); // Color del placeholder
    }

    private void initialize() {
        System.out.println("Inicializando etiquetas y listeners...");
        this.vista.lblIngresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.vista.lblIngresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == vista.lblIngresar) {
                    System.out.println("Label Ingresar presionada");
                    VerificarCredenciales();
                }
            }
        });
        this.vista.lblMostrarContraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));  // Cambiar el cursor
        this.vista.lblMostrarContraseña.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (mostrarContraseña) {
                    // Ocultar la contraseña
                    vista.txtContraseñaa.setEchoChar('*');
                    mostrarContraseña = false;
                } else {
                    // Mostrar la contraseña
                    vista.txtContraseñaa.setEchoChar((char) 0);
                    mostrarContraseña = true;
                }
            }
        });

        // Agregar MouseListener a los campos de texto
        vista.txtCorreo.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtCorreo, "Ingrese su Correo Electrónico...");
            }
        });

        vista.txtContraseñaa.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evt) {
                txtMousePressed(vista.txtContraseñaa, "************");
            }
        });

    }

}
