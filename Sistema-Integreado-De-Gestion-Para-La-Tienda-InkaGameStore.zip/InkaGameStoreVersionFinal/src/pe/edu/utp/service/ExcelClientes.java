package pe.edu.utp.service;

import pe.edu.utp.entity.Clientes;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Desktop;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ExcelClientes {

    public static void generarReporteClientes(List<Clientes> clientes) {
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("Clientes");

        try {
            // Inserta el logotipo en el reporte si existe
            InputStream is = new FileInputStream("src/pe/edu/utp/assets/logoinka.png");
            byte[] bytes = IOUtils.toByteArray(is);
            int imgIndex = book.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);
            is.close();

            Drawing<?> drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = book.getCreationHelper().createClientAnchor();
            anchor.setCol1(0); // Columna donde inicia la imagen
            anchor.setRow1(0); // Fila donde inicia la imagen
            Picture pict = drawing.createPicture(anchor, imgIndex);
            pict.resize(1, 3); // Ajusta el tamaño de la imagen

            // Información de la empresa
            Row rowEmpresa = sheet.createRow(4);
            CellStyle estiloEmpresa = crearEstiloEmpresa(book);
            rowEmpresa.createCell(1).setCellValue("Nombre de la Empresa: Inka Game Store");
            rowEmpresa.getCell(1).setCellStyle(estiloEmpresa);

            Row rowRUC = sheet.createRow(5);
            rowRUC.createCell(1).setCellValue("RUC: 12345678901");
            rowRUC.getCell(1).setCellStyle(estiloEmpresa);

            Row rowDescripcion = sheet.createRow(6);
            rowDescripcion.createCell(1).setCellValue("Descripción: Empresa dedicada a venta de respuestos de hardware de PC o Portatil.");
            rowDescripcion.getCell(1).setCellStyle(estiloEmpresa);

            // Fecha del reporte
            Row rowFecha = sheet.createRow(7);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String fechaActual = sdf.format(new Date());
            rowFecha.createCell(1).setCellValue("Fecha del reporte: " + fechaActual);
            rowFecha.getCell(1).setCellStyle(estiloEmpresa);

            // Crear encabezados para la tabla de clientes
            Row header = sheet.createRow(9); // Fila donde empieza la tabla
            String[] titulos = {"Direccioón", "DNI", "Nombre Completo", "Telefono"};
            CellStyle headerStyle = crearEstiloEncabezado(book);
            for (int i = 0; i < titulos.length; i++) {
                Cell cell = header.createCell(i + 1); // Comienza desde la columna 1
                cell.setCellValue(titulos[i]);
                cell.setCellStyle(headerStyle);
            }

            // Rellena el reporte con datos de clientes
            int numFilaDatos = 10; // Empieza en la fila después del encabezado
            CellStyle datosEstilo = crearEstiloDatos(book);
            for (Clientes cliente : clientes) {
                Row filaDatos = sheet.createRow(numFilaDatos++);
                filaDatos.createCell(1).setCellValue(cliente.getDNI());
                filaDatos.createCell(2).setCellValue(cliente.getNombreCompleto());
                filaDatos.createCell(3).setCellValue(cliente.getTelefono());
                filaDatos.createCell(4).setCellValue(cliente.getDireccion());

                for (int i = 1; i <= 4; i++) { // Aplica estilo a todas las columnas
                    filaDatos.getCell(i).setCellStyle(datosEstilo);
                }
            }

            // Ajusta automáticamente el ancho de las columnas
            for (int i = 1; i <= 4; i++) {
                sheet.autoSizeColumn(i);
            }

            // Exporta el archivo Excel
            String home = System.getProperty("user.home");
            File file = new File(home + "/Downloads/ReporteClientes.xlsx");
            FileOutputStream fileOut = new FileOutputStream(file);
            book.write(fileOut);
            fileOut.close();
            Desktop.getDesktop().open(file);
            JOptionPane.showMessageDialog(null, "Reporte Generado");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private static CellStyle crearEstiloEmpresa(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        Font font = book.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        estilo.setFont(font);
        return estilo;
    }

    private static CellStyle crearEstiloEncabezado(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        estilo.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        estilo.setBorderTop(BorderStyle.THIN);
        Font font = book.createFont();
        font.setBold(true);
        estilo.setFont(font);
        return estilo;
    }

    private static CellStyle crearEstiloDatos(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        return estilo;
    }
}

