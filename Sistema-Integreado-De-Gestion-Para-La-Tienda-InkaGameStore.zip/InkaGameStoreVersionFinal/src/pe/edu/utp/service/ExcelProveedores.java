package pe.edu.utp.service;

import pe.edu.utp.entity.Proveedor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Desktop;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ExcelProveedores {

    public static void generarReporteProveedores(List<Proveedor> proveedores) {
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("Proveedores");

      try {
            // Inserta el logotipo en el reporte si existe
            InputStream is = new FileInputStream("src/pe/edu/utp/assets/logoinka.png");
            byte[] bytes = IOUtils.toByteArray(is);
            int imgIndex = book.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);
            is.close();

            Drawing<?> drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = book.getCreationHelper().createClientAnchor();
            anchor.setCol1(0); // Columna donde inicia la imagen
            anchor.setRow1(0); // Fila donde inicia la imagen
            Picture pict = drawing.createPicture(anchor, imgIndex);
            pict.resize(1, 3); // Ajusta el tamaño de la imagen

            // Información de la empresa
            Row rowEmpresa = sheet.createRow(4);
            CellStyle estiloEmpresa = crearEstiloEmpresa(book);
            rowEmpresa.createCell(1).setCellValue("Nombre de la Empresa: Inka Game Store");
            rowEmpresa.getCell(1).setCellStyle(estiloEmpresa);

            Row rowRUC = sheet.createRow(5);
            rowRUC.createCell(1).setCellValue("RUC: 12345678901");
            rowRUC.getCell(1).setCellStyle(estiloEmpresa);

            Row rowDescripcion = sheet.createRow(6);
            rowDescripcion.createCell(1).setCellValue("Descripción: Empresa dedicada a venta de respuestos de hardware de PC o Portatil.");
            rowDescripcion.getCell(1).setCellStyle(estiloEmpresa);

            // Fecha del reporte
            Row rowFecha = sheet.createRow(7);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String fechaActual = sdf.format(new Date());
            rowFecha.createCell(1).setCellValue("Fecha del reporte: " + fechaActual);
            rowFecha.getCell(1).setCellStyle(estiloEmpresa);


            // Crear encabezados para el reporte
            Row header = sheet.createRow(10);
            header.createCell(0).setCellValue("ID");
            header.createCell(1).setCellValue("RUC");
            header.createCell(2).setCellValue("Nombres y Apellidos");
            header.createCell(3).setCellValue("Teléfono");
            header.createCell(4).setCellValue("Dirección");
            header.createCell(5).setCellValue("Correo");

            // Aplica estilos a los encabezados
            CellStyle headerStyle = book.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);
            headerStyle.setBorderTop(BorderStyle.THIN);
            Font font = book.createFont();
            font.setBold(true);
            headerStyle.setFont(font);
            for (int i = 0; i < 6; i++) {
                header.getCell(i).setCellStyle(headerStyle);
            }

            // Rellena el reporte con datos de proveedores
            int numFilaDatos = 11; // Empieza en la fila 11
            CellStyle datosEstilo = book.createCellStyle();
            datosEstilo.setBorderBottom(BorderStyle.THIN);
            datosEstilo.setBorderLeft(BorderStyle.THIN);
            datosEstilo.setBorderRight(BorderStyle.THIN);

            for (Proveedor proveedor : proveedores) {
                Row filaDatos = sheet.createRow(numFilaDatos++);
                filaDatos.createCell(0).setCellValue(proveedor.getProveedorID());
                filaDatos.createCell(1).setCellValue(proveedor.getRuc());
                filaDatos.createCell(2).setCellValue(proveedor.getNombreCompleto());
                filaDatos.createCell(3).setCellValue(proveedor.getTelefono());
                filaDatos.createCell(4).setCellValue(proveedor.getDireccion());
                filaDatos.createCell(5).setCellValue(proveedor.getCorreo());

                // Aplica el estilo de datos a cada celda
                for (int i = 0; i < 6; i++) {
                    filaDatos.getCell(i).setCellStyle(datosEstilo);
                }
            }

            // Ajusta automáticamente el ancho de las columnas
            for (int i = 0; i < 6; i++) {
                sheet.autoSizeColumn(i);
            }

            // Exporta el archivo Excel a la carpeta de descargas del usuario
            String home = System.getProperty("user.home");
            File file = new File(home + "/Downloads/ReporteProveedores.xlsx");
            FileOutputStream fileOut = new FileOutputStream(file);
            book.write(fileOut);
            fileOut.close();
            Desktop.getDesktop().open(file);
            JOptionPane.showMessageDialog(null, "Reporte Generado");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
     private static CellStyle crearEstiloEmpresa(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        Font font = book.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        estilo.setFont(font);
        return estilo;
    }

    private static CellStyle crearEstiloEncabezado(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        estilo.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        estilo.setBorderTop(BorderStyle.THIN);
        Font font = book.createFont();
        font.setBold(true);
        estilo.setFont(font);
        return estilo;
    }

    private static CellStyle crearEstiloDatos(Workbook book) {
        CellStyle estilo = book.createCellStyle();
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        return estilo;
    }
}
