package pe.edu.utp.daoImpl;

import java.awt.Image;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import pe.edu.utp.config.Conexion;
import pe.edu.utp.dao.ProveedorDao;
import pe.edu.utp.entity.Proveedor;

/**
 *
 * @author javie
 */
public class ProveedorDaoImpl extends Conexion implements ProveedorDao {

    @Override
    public boolean createProveedor(Proveedor p) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO proveedor (NombreCompleto, RUC, Telefono, Correo, Direccion, FotoLogo, RutaLogo) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombreCompleto());
            ps.setString(2, p.getRuc());
            ps.setString(3, p.getTelefono());
            ps.setString(4, p.getCorreo());
            ps.setString(5, p.getDireccion());
            ps.setString(7, p.getImagenRuta());
            FileInputStream archivofoto = new FileInputStream(p.getImagenRuta());
            ps.setBinaryStream(6, archivofoto);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProveedorDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.err.println(e);
            }
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
        return false;
    }

    @Override
    public boolean updateProveedor(Proveedor p) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "UPDATE proveedor SET RUC = ?, NombreCompleto = ?, Direccion = ?, Telefono = ?, Correo = ?, FotoLogo = ?, RutaLogo = ? WHERE Proveedor_ID = ?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getRuc());
            ps.setString(2, p.getNombreCompleto());
            ps.setString(3, p.getDireccion());
            ps.setString(4, p.getTelefono());
            ps.setString(5, p.getCorreo());
            ps.setString(7, p.getImagenRuta());
            FileInputStream archivofoto = new FileInputStream(p.getImagenRuta());
            ps.setBinaryStream(6, archivofoto);
            ps.setInt(8, p.getProveedorID());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProveedorDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.err.println(e);
            }
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
        return false;
    }

    @Override
    public boolean deleteProveedor(int id) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "DELETE FROM proveedor WHERE Proveedor_ID = ?"; // Asegúrate de usar el nombre correcto de la columna

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.err.println(e);
            }
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    @Override
    public boolean readProveedor(Proveedor p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Proveedor> readAllProveedor() {
        List<Proveedor> listaProveedor = new ArrayList<>();
        String sql = "SELECT * FROM proveedor";

        try (Connection con = getConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int proveedorID = rs.getInt("Proveedor_ID"); // Ajusta el nombre de la columna según tu base de datos
                String ruc = rs.getString("RUC");
                String nombreCompleto = rs.getString("NombreCompleto");
                String telefono = rs.getString("Telefono");
                String direccion = rs.getString("Direccion");
                String correo = rs.getString("Correo");
                byte[] imagenBytes = rs.getBytes("FotoLogo");
                ImageIcon imagenT = null;
                if (imagenBytes != null) {
                    ImageIcon icon = new ImageIcon(imagenBytes);
                    Image img = icon.getImage();
                    Image newImg = img.getScaledInstance(160, 160, Image.SCALE_SMOOTH);
                    imagenT = new ImageIcon(newImg);
                }
                String imagenRuta = rs.getString("RutaLogo");

                Proveedor proveedor = new Proveedor(proveedorID, nombreCompleto, ruc, telefono, direccion, correo, imagenT, imagenRuta);
                listaProveedor.add(proveedor);
            }
        } catch (SQLException e) {
            System.err.println("Error en la consulta: " + e.getMessage());
        }

        return listaProveedor;
    }

    @Override
    public List<Proveedor> readProveedor(String ruc) {
        List<Proveedor> listaProveedor = new ArrayList<>();
        String sql = "SELECT * "
                + "FROM proveedor "
                + "WHERE LOWER(RUC) LIKE LOWER(?)";

        try (java.sql.Connection con = getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            // Ajustar el parámetro de búsqueda para el LIKE
            ps.setString(1, "%" + ruc + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int proveedorID = rs.getInt("Proveedor_ID"); // Ajusta el nombre de la columna según tu base de datos
                    String RUC = rs.getString("RUC");
                    String nombreCompleto = rs.getString("NombreCompleto");
                    String telefono = rs.getString("Telefono");
                    String direccion = rs.getString("Direccion");
                    String correo = rs.getString("Correo");
                    byte[] imagenBytes = rs.getBytes("FotoLogo");
                    ImageIcon imagenT = null;
                    if (imagenBytes != null) {
                        ImageIcon icon = new ImageIcon(imagenBytes);
                        Image img = icon.getImage();
                        Image newImg = img.getScaledInstance(160, 160, Image.SCALE_SMOOTH);
                        imagenT = new ImageIcon(newImg);
                    }
                    String imagenRuta = rs.getString("RutaLogo");

                    Proveedor proveedor = new Proveedor(proveedorID, nombreCompleto, RUC, telefono, direccion, correo, imagenT, imagenRuta);
                    listaProveedor.add(proveedor);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error en la consulta: " + e.getMessage());
        }

        return listaProveedor;
    }

}
