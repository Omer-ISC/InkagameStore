package pe.edu.utp.entity;

import javax.swing.Icon;

public class Proveedor {

    private int proveedorID; 
    private String nombreCompleto;
    private String ruc;
    private String telefono; 
    private String direccion; 
    private String correo;
    private Icon Imagen;
    private String ImagenRuta;

    public Proveedor() {
    }

    public Proveedor(int proveedorID, String nombreCompleto, String ruc, String telefono, String direccion, String correo, Icon Imagen, String ImagenRuta) {
        this.proveedorID = proveedorID;
        this.nombreCompleto = nombreCompleto;
        this.ruc = ruc;
        this.telefono = telefono;
        this.direccion = direccion;
        this.correo = correo;
        this.Imagen = Imagen;
        this.ImagenRuta = ImagenRuta;
    }

    public int getProveedorID() {
        return proveedorID;
    }

    public void setProveedorID(int proveedorID) {
        this.proveedorID = proveedorID;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Icon getImagen() {
        return Imagen;
    }

    public void setImagen(Icon Imagen) {
        this.Imagen = Imagen;
    }

    public String getImagenRuta() {
        return ImagenRuta;
    }

    public void setImagenRuta(String ImagenRuta) {
        this.ImagenRuta = ImagenRuta;
    }

    @Override
    public String toString() {
        return "Proveedor{" + "proveedorID=" + proveedorID + ", nombreCompleto=" + nombreCompleto + ", ruc=" + ruc + ", telefono=" + telefono + ", direccion=" + direccion + ", correo=" + correo + ", Imagen=" + Imagen + ", ImagenRuta=" + ImagenRuta + '}';
    }

    
}
